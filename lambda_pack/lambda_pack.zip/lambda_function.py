# sweetsoup_bot.py
# renamed as lambda_function.py for running
from logic import get_menu, juk_menu, chn_menu


keyboard_button = {
    "keyboard": {
        "type": "buttons",
        "buttons": [
            "오늘의 학식(죽전)",
            "오늘의 학식(천안)",
            "MS오피스 설치",
            "도움말"
        ]
    }
}


def lambda_handler(event, context):
    data = event
    content = data.get('content')

    if content == "오늘의 학식(죽전)":
        data_send = {
            "message": {
                "text": f"죽전, 오늘의 학식\n {juk_menu()}"
            }
        }
        result = dict(data_send, **keyboard_button)
        return result

    elif content == "오늘의 학식(천안)":
        data_send = {
            "message": {
                "text": f"천안, 오늘의 학식\n {chn_menu()}"
            }
        }
        result = dict(data_send, **keyboard_button)
        return result

    elif content == "MS오피스 설치":
        pc_link = 'http://cms.dankook.ac.kr/web/office'
        ios_link = 'https://itunes.apple.com/kr/developer/microsoft-corporation/id298856275'
        and_link = 'https://play.google.com/store/apps/dev?id=6720847872553662727'
        data_send = {
            "message": {
                "text": "Office365 설치를 위해, 단국대 학교 이메일과 패스워드를 알고 있어야 합니다!\n"
                        "최초로 부여받은 비밀번호(생년월일)의 경우 로그인이 불가하여\n"
                        "꼭! 비밀번호 변경 후 이용해주시길 바랍니다.\n"
                        "\n-PC설치방법-\n"
                        f"사이트: {pc_link}\n"
                        "오피스 포털 접속 -> Office364 포털 클릭 -> Office앱 설치\n\n"
                        f"Android - {and_link}\n\n"
                        f"iOS - {ios_link}"
            }
        }
        result = dict(data_send, **keyboard_button)
        return result

    elif content == "도움말":
        data_send = {
            "message": {
                "text": "피드백 보내기\n"
                        "E-mail : roamgom@gmail.com\n"
                        "SweetSoup(중고서적) : URL"
            }
        }
        result = dict(data_send, **keyboard_button)
        return result
    else:
        return keyboard_button['keyboard']


if __name__ == '__main__':
    juk_menu()

